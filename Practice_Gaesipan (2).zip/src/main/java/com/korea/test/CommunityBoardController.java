package com.korea.test;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.CommunityDAO;
import util.MyPath;
import util.Paging;
import vo.CommentVO;
import vo.CommunityVO;

@Controller
public class CommunityBoardController {
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	CommunityDAO community_dao;
	
	//페이지별 목록 조회
	@RequestMapping("/community_list.do")
	public String list( Model model, String page ) {
			
		int nowPage = 1; 
			
		//list.do <------ null 
		//list.do?page= <------ empty
		if( page != null ) {
			nowPage = Integer.parseInt( page );
		}
			
		//한 페이지에 표시될 게시물의 시작과 끝번호를 계산
		//page가 1이면 1 ~ 10까지 계산이 되어야 하고, 
		//page가 2면 11 ~ 20까지 계산이 되어야 한다....
		int start = (nowPage - 1) * MyPath.Communityboard.BLOCKLIST + 1;
		int end = start + MyPath.Communityboard.BLOCKLIST - 1;
			
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("start", start);
		map.put("end", end);
			
		//페이지 번호에 따른 게시글 조회
		List<CommunityVO> list = community_dao.selectList( map );
			
		//전체게시글 수 구하기 
		int rowTotal = community_dao.getRowTotal();
			
		//페이지 메뉴 생성하기 
		String pageMenu = Paging.getPaging(
							"community_list.do", 
							nowPage, 
							rowTotal, 
							MyPath.Communityboard.BLOCKLIST, 
							MyPath.Communityboard.BLOCKPAGE);
		
		//조회수를 위해 저장해뒀던 show라는 정보를 세션에서 제거
		request.getSession().removeAttribute("show");
		
		//리퀘스트 영역에 바인딩 
		model.addAttribute("list", list);
		model.addAttribute("pageMenu", pageMenu);
			
		return MyPath.Communityboard.VIEW_PATH + "community_board_list.jsp?page="+nowPage;
	}
	
	//새 글 쓰는 페이지로 이동
	@RequestMapping("/community_insert_form.do")
	public String insert_form() {
		return MyPath.Communityboard.VIEW_PATH + "community_insert_form.jsp";
	}
	
	//새 글 추가하기
	@RequestMapping("/community_insert.do")
	public String insert(CommunityVO vo) {
		
		String ip = request.getRemoteAddr();
		vo.setIp(ip);
		int res = community_dao.insert(vo);
		
		if(res>0) {
			return "redirect:community_list.do";
		}
		
		return null;
	}
	
	//글 조회하는 페이지로 이동
	@RequestMapping("/community_view.do")
	public String view( Model model, int idx ) {
		
		//idx에 해당하는 게시글 하나 보기 
		CommunityVO vo = community_dao.selectOne(idx);
		
		//idx에 해당하는 댓글 보기 
		List<CommentVO> comment_list = community_dao.select_com_One(idx);
		
		//idx에 해당하는 댓글 갯수 구하기.
		int commentTotal = community_dao.getCommentTotal(idx);
		
		//조회수 증가
		HttpSession session = request.getSession();
		String show = (String)session.getAttribute("show"); 
		
		if( show == null ) {
			int res = community_dao.update_readhit( idx );
			session.setAttribute("show", "0");
		}
			
		//상세보기페이지로 전환하기 위해 바인딩 및 포워딩 
		model.addAttribute("vo", vo);
		model.addAttribute("list", comment_list);
		model.addAttribute("commentTotal", commentTotal);
		return MyPath.Communityboard.VIEW_PATH + "community_board_view.jsp";
	}
	
	//댓글 작성 
	@RequestMapping("/comment.do")
	@ResponseBody
	public String comment(Model model, CommentVO vo ) {
		
		String ip = request.getRemoteAddr();
		vo.setIp(ip);
		
		//댓글 작성
		int res = community_dao.comment_insert(vo);
		
		if(res>0) {
			return "comment_success";
		}
		
		return "comment_fail";
	}
	
	//게시글 삭제
	@RequestMapping("/community_del.do")
	@ResponseBody
	public String del(int idx) {
		int res = community_dao.delete(idx);
		
		if( res > 0 ) {
			return "del_success";
		}
		return "del_fail";
	}
	
	//게시글 수정하는 페이지로 이동
	@RequestMapping("/community_modify_form.do")
	public String modifyform(Model model, int idx) {
		
		//수정할 게시글 조회 
		CommunityVO vo = community_dao.selectOne(idx);
		
		model.addAttribute("vo", vo);
		return MyPath.Communityboard.VIEW_PATH + "community_modify_form.jsp";
	}
	
	//게시글 수정 
	@RequestMapping("/community_modify.do")
	@ResponseBody
	public String modify(CommunityVO vo) {
		int res = community_dao.update(vo);
		
		if( res > 0 ) {
			return "modify_success";
		}
		return "modify_fail";
	}
	
	/*
	 * //게시글 검색
	 * 
	 * @RequestMapping("/search_by_title.do") public String search_title(String
	 * search_op, String page) {
	 * 
	 * int nowPage = 1;
	 * 
	 * //list.do <------ null //list.do?page= <------ empty if( page != null ) {
	 * nowPage = Integer.parseInt( page ); }
	 * 
	 * //한 페이지에 표시될 게시물의 시작과 끝번호를 계산 //page가 1이면 1 ~ 10까지 계산이 되어야 하고, //page가 2면 11
	 * ~ 20까지 계산이 되어야 한다.... int start = (nowPage - 1) *
	 * MyPath.Inquiryboard.BLOCKLIST + 1; int end = start +
	 * MyPath.Inquiryboard.BLOCKLIST - 1;
	 * 
	 * HashMap<String, Integer> map = new HashMap<String, Integer>();
	 * map.put("start", start); map.put("end", end);
	 * 
	 * //페이지 번호에 따른 게시글 조회 List<CommunityVO> list = community_dao.searchList( map,
	 * search_op ); }
	 */
	
	
}
