package com.korea.test;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.InquiryDAO;
import util.MyPath;
import util.Paging;
import vo.InquiryVO;

@Controller
public class InquiryBoardController {
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	InquiryDAO inquiry_dao;
	
	//페이지별 목록 조회
	@RequestMapping("/inquiry_list.do")
	public String list( Model model, String page ) {
		
		int nowPage = 1; 
		
		//list.do <------ null 
		//list.do?page= <------ empty
		if( page != null ) {
			nowPage = Integer.parseInt( page );
		}
		
		//한 페이지에 표시될 게시물의 시작과 끝번호를 계산
		//page가 1이면 1 ~ 10까지 계산이 되어야 하고, 
		//page가 2면 11 ~ 20까지 계산이 되어야 한다....
		int start = (nowPage - 1) * MyPath.Inquiryboard.BLOCKLIST + 1;
		int end = start + MyPath.Inquiryboard.BLOCKLIST - 1;
		
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("start", start);
		map.put("end", end);
		
		//페이지 번호에 따른 게시글 조회
		List<InquiryVO> list = inquiry_dao.selectList( map );
		
		//전체게시글 수 구하기 
		int rowTotal = inquiry_dao.getRowTotal();
		
		//페이지 메뉴 생성하기 
		String pageMenu = Paging.getPaging(
							"inquiry_list.do", 
							nowPage, 
							rowTotal, 
							MyPath.Inquiryboard.BLOCKLIST, 
							MyPath.Inquiryboard.BLOCKPAGE);
		
		//리퀘스트 영역에 바인딩 
		model.addAttribute("list", list);
		model.addAttribute("pageMenu", pageMenu);
		
		return MyPath.Inquiryboard.VIEW_PATH + "inquiry_board_list.jsp?page="+nowPage;
	}
	
	//새 글 쓰는 페이지로 이동
	@RequestMapping("inquiry_insert_form.do")
	public String insert_form() {
		return MyPath.Inquiryboard.VIEW_PATH + "inquiry_insert_form.jsp";
	}
	
	//새 글 추가하기
	@RequestMapping("inquiry_insert.do")
	public String insert(InquiryVO vo) {
		
		String ip = request.getRemoteAddr();
		vo.setIp(ip);
		int res = inquiry_dao.insert( vo );
		
		if(res>0) {
			return "redirect:inquiry_list.do";
		}
		
		return null;
	}
	
	//글 조회하는 페이지로 이동
	@RequestMapping("inquiry_view.do")
	public String view( Model model, int idx ) {
		InquiryVO vo = inquiry_dao.selectOne(idx);
		
		//상세보기페이지로 전환하기 위해 바인딩 및 포워딩 
		model.addAttribute("vo", vo);
		
		return MyPath.Inquiryboard.VIEW_PATH + "inquiry_board_view.jsp";
	}
	
	//답글 다는 페이지로 이동 
	@RequestMapping("inquiry_reply_form.do")
	public String reply_form( int idx, int page, String title) {
		return MyPath.Inquiryboard.VIEW_PATH + "inquiry_reply_form.jsp?idx=" + idx + "&page=" + page;
	}
	
	//답글 작성 
	@RequestMapping("inquiry_reply.do")
	public String reply( InquiryVO vo, int idx, int page ) {
		String ip = request.getRemoteAddr();
		
		//답글을 달고 싶은 게시글 정보
		InquiryVO base_vo = inquiry_dao.selectOne(idx);
		
		int res = inquiry_dao.update_step(base_vo);
		
		vo.setIp(ip);
		vo.setRef(base_vo.getRef());
		vo.setStep(base_vo.getStep() + 1);
		vo.setDepth(base_vo.getDepth() + 1);
		vo.setSecret_con(base_vo.getSecret_con());
		
		//"이메일 답장 받기" 옵션에 체크됐는지 여부 확인 
		int email_rep_on = base_vo.getEmail_rep_on();
		
		//체크됐으면 이메일 답장 달기
		if(email_rep_on == 1) {
			String email_receiver = base_vo.getEmail();
			String email_title = "[어쩌구영화제] 안녕하세요. " + base_vo.getWriter() + "님. 문의하신 게시글에 답변이 올라왔습니다.";
			String email_content = "[어쩌구영화제] 안녕하세요. " + base_vo.getWriter() + "님. 문의하신 게시글에 답변이 올라왔습니다.";
			
			//이메일 전송
			SimpleEmail email = new SimpleEmail();
			email.setHostName("smtp.naver.com");
			email.setSmtpPort(465);
			email.setCharset("euc-kr");
			email.setAuthenticator(new DefaultAuthenticator("j_espresso@naver.com", "xsw23edcXSW@#EDC"));
			email.setSSLOnConnect(true);
			
			try {
				email.setFrom("j_espresso@naver.com", "어쩌구영화제");
				email.setSubject(email_title);
				email.setMsg(email_content);
				email.addTo(email_receiver, "전인수");
				email.send();
			} catch (EmailException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		

		
		//댓글등록 
		res = inquiry_dao.reply(vo);
		if( res > 0) {
			return "inquiry_list.do";
		}
		
		return null;
	}
	
	//게시글 삭제
	@RequestMapping("inquiry_del.do")
	@ResponseBody
	public String del( int idx) {
		
		int res = inquiry_dao.delete(idx);
		
		if( res > 0 ) {
			return "del_success";
		}
		return "del_fail";
	}
}
