package com.korea.test;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import dao.PrefestivalDAO;
import util.MyPath;
import vo.PrefestivalVO;

@Controller
public class MainController {
	
	@Autowired
	PrefestivalDAO prefestival_dao;
	
	//메인페이지
	@RequestMapping(value = {"/","/mainpage.do"})
	public String list () {
			return MyPath.Mainpage.VIEW_PATH + "mainpage.jsp";
	}
	
	//FAQ창으로 이동 
	@RequestMapping("/faq_view.do")
	public String faq_view() {
		return MyPath.Etcpage.VIEW_PATH + "faq_view.jsp";
	}
	
	@RequestMapping("/test.do")
	public String test() {
		return MyPath.Etcpage.VIEW_PATH + "test.jsp";
	}
	
	@RequestMapping("/pre_festival.do")
	public String list(Model model) {
		List<PrefestivalVO> list = prefestival_dao.selectList();
		model.addAttribute("list", list);
		
		return MyPath.Etcpage.VIEW_PATH + "festival_preceding.jsp";
				
	}
}
