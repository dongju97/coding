package com.korea.test;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.scribejava.core.model.OAuth2AccessToken;

import dao.MemberDAO;
import naverlogin.NaverLoginBO;
import util.MyPath;
import util.Paging;
import vo.InquiryVO;
import vo.MemberVO;

@Controller
public class MemberController {
	@Autowired
	ServletContext application;
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	MemberDAO member_dao;
	
	/* NaverLoginBO */	
	private NaverLoginBO naverLoginBO;	
	private String apiResult = null;
	
	
	public void setMember_dao(MemberDAO member_dao) {
		this.member_dao = member_dao;
	}
	
	@Autowired	
	private void setNaverLoginBO(NaverLoginBO naverLoginBO) {	
			this.naverLoginBO = naverLoginBO;	
	}
	
	//로그인 페이지로 이동
	@RequestMapping("/login.do")
	public String login() {
		return MyPath.Memberadminpage.VIEW_PATH + "login_form.jsp";
	}
	
	//회원가입 페이지로 이동
	@RequestMapping("/register_form.do")
	public String registerForm() {
		return MyPath.Memberadminpage.VIEW_PATH + "register_form.jsp";
	}
	
	//회원가입
	@RequestMapping("/register.do")
	public String insert(MemberVO vo, Model model) {
		int res = member_dao.insert(vo);
		
		if( res > 0) {
			return MyPath.Memberadminpage.VIEW_PATH + "login_form.jsp";
		}
		
		return null;
	}
	
	//아이디 중복 체크
	@RequestMapping("/check_id.do")
	@ResponseBody
	public String check(String id) {
	
		MemberVO vo = member_dao.selectOne(id);
		
		String result = "no";
		
		if(vo != null) {
			result = "yes";
		}else {
			result = "no";
		}
		return result;
	}
	
	//로그인
	@RequestMapping("/login_action.do")
	@ResponseBody
	public String login_action(String id, String pwd) {
		String result = "login";
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("pwd", pwd);

		MemberVO login_vo = member_dao.selectLogin(map);
		request.getSession().setAttribute("vo_login", login_vo);
		
		if(login_vo == null) {
			result = "no_id";
		}
		if(login_vo.getPwd().equals(map.get(pwd))) {
			result = "no_pwd";
		}
		return result;
	}
	
	//로그아웃
	@RequestMapping("/logout.do")
	public String logout() {
		request.getSession().removeAttribute("vo_login");
		
		return MyPath.Mainpage.VIEW_PATH + "mainpage.jsp";
	}
	
	//회원정보 페이지로 이동
	@RequestMapping("/mypage.do")
	public String mypage(Model model, String id, String page) {
		
		int nowPage = 1; 
		
		//list.do <------ null 
		//list.do?page= <------ empty
		if( page != null ) {
			nowPage = Integer.parseInt( page );
		}
		
		//한 페이지에 표시될 게시물의 시작과 끝번호를 계산
		//page가 1이면 1 ~ 10까지 계산이 되어야 하고, 
		//page가 2면 11 ~ 20까지 계산이 되어야 한다....
		int start = (nowPage - 1) * MyPath.Memberadminpage.BLOCKLIST + 1;
		int end = start + MyPath.Memberadminpage.BLOCKLIST - 1;
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);
		map.put("id", id);
		
		//내 id에 해당하는 문의들 가져오기
		List<InquiryVO> list = member_dao.memInfo_Inquiry(map);
		
		//전체게시글 수 구하기 
		int rowTotal = member_dao.getRowTotal(id);
		
		//페이지 메뉴 생성하기 
		String pageMenu = Paging.getPaging(
					"mypage_inquiry.do", 
					nowPage, 
					rowTotal, 
					MyPath.Memberadminpage.BLOCKLIST, 
					MyPath.Memberadminpage.BLOCKPAGE);	
		
		//리퀘스트 영역에 바인딩 
		model.addAttribute("list", list);
		model.addAttribute("pageMenu", pageMenu);
		
		return MyPath.Memberadminpage.VIEW_PATH + "login_mypage.jsp";
	}
	
	//회원정보 수정
	@RequestMapping("/modify_form.do")
	public String modify_form() {
		return MyPath.Memberadminpage.VIEW_PATH + "loginfo_modify.jsp";
	}
	
	//나의 1대1문의 페이지로 
	@RequestMapping("/mypage_inquiry.do")
	public String mypage_inquiry(Model model, String id, String page) {
		
		int nowPage = 1; 
		
		//list.do <------ null 
		//list.do?page= <------ empty
		if( page != null ) {
			nowPage = Integer.parseInt( page );
		}
		
		//한 페이지에 표시될 게시물의 시작과 끝번호를 계산
		//page가 1이면 1 ~ 10까지 계산이 되어야 하고, 
		//page가 2면 11 ~ 20까지 계산이 되어야 한다....
		int start = (nowPage - 1) * MyPath.Memberadminpage.BLOCKLIST + 1;
		int end = start + MyPath.Memberadminpage.BLOCKLIST - 1;
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);
		map.put("id", id);
		
		//내 id에 해당하는 문의들 가져오기
		List<InquiryVO> list = member_dao.memInfo_Inquiry(map);
		
		//전체게시글 수 구하기 
		int rowTotal = member_dao.getRowTotal(id);
		
		//페이지 메뉴 생성하기 
		String pageMenu = Paging.getPaging(
					"mypage_inquiry.do", 
					nowPage, 
					rowTotal, 
					MyPath.Memberadminpage.BLOCKLIST, 
					MyPath.Memberadminpage.BLOCKPAGE);	
		
		//리퀘스트 영역에 바인딩 
		model.addAttribute("list", list);
		model.addAttribute("pageMenu", pageMenu);
		
		return MyPath.Memberadminpage.VIEW_PATH + "login_myinquiry.jsp?page="+nowPage;
	}
	
	// 네이버 계정으로 로그인 하는 경우 
	@RequestMapping(value = "/naver_login.do")
	public String naver_login(Model model, HttpSession session) {
		
		// 네이버아이디로 인증 URL을 생성하기 위하여 naverLoginBO클래스의 getAuthorizationUrl 메소드 호출
		String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
		
		
		//https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=sE***************&
		//redirect_uri=http%3A%2F%2F211.63.89.90%3A8090%2Flogin_project%2Fcallback&state=e68c269c-5ba9-4c31-85da-54c16c658125
		
		//네이버 
		model.addAttribute("url", naverAuthUrl);
		
		return MyPath.Memberadminpage.VIEW_PATH + "login_naver.jsp";
	}
	
	//네이버 로그인 성공시 callback 호출 메서드 
	@RequestMapping(value = "/naver_login_callback.do", method = {RequestMethod.GET, RequestMethod.POST} )
	public String callback(Model model, @RequestParam String code, @RequestParam String state, HttpSession session) throws IOException, ParseException, org.json.simple.parser.ParseException{
		
		OAuth2AccessToken oauthToken;
	oauthToken = naverLoginBO.getAccessToken(session, code, state);
	
	//1. 로그인 사용자 정보를 읽어온다. 
		apiResult = naverLoginBO.getUserProfile(oauthToken); //String 형식의 json 데이터
	
		/* apiResult json 구조		
		{"resultcode":"00",
		 "message":"success",
		 "response":{"id":"XiHXDX1yfEGv3eDoYohjhcV-UBxUxBaXrR4wGoUdZpg",
		 			 "nickname":"mum",
		 			 "email":"mumberrymountain@naver.com",
		 			 "mobile":"010-8820-1758",
		 			 "mobile_e164":"+821088201758",
		 			 "name":"\uc804\uc778\uc218",
		 			 "birthday":"06-13",
		 			 "birthyear":"1994"}}*/
		
		//2. String 형식인 apiResult를 json형태로 바꿈 
		JSONParser parser = new JSONParser();
		Object obj;
		obj = parser.parse(apiResult);
		JSONObject jsonObj = (JSONObject) obj;
		
		
		//3. 데이터 파싱 
		//Top레벨 단계 _response 파싱 
		
		JSONObject response_obj = (JSONObject)jsonObj.get("response");
		
		//respon의 nickname값 파싱 
		String name = (String)response_obj.get("name");
		String email = (String)response_obj.get("email");
		String id = (String)response_obj.get("id");
		String nickname = (String)response_obj.get("nickname");
		String mobile = (String)response_obj.get("mobile");
		String birthyear = (String)response_obj.get("birthyear");
		String birthday = (String)response_obj.get("birthday");
		String birth = birthyear + "-" + birthday;
		
		MemberVO naver_vo = new MemberVO();
		naver_vo.setName(name);
		naver_vo.setId(id);
		naver_vo.setMail(email);
		naver_vo.setCell(mobile);
		naver_vo.setNickname(nickname);
		naver_vo.setBirth_date(birth);
		
		MemberVO vo = member_dao.select(naver_vo);
		
		if(vo == null) {
			int res = member_dao.outer_insert(naver_vo);
			
			if( res > 0) {
				
				MemberVO login_vo = member_dao.select(naver_vo);
				request.getSession().setAttribute("vo_login", login_vo);
				
				return MyPath.Mainpage.VIEW_PATH + "mainpage.jsp";
			}
			return null;
		}
		
		request.getSession().setAttribute("vo_login", vo);
		
		return MyPath.Mainpage.VIEW_PATH + "mainpage.jsp";
	}
}
