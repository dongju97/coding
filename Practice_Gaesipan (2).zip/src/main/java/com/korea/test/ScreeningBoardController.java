package com.korea.test;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import dao.ScreeningDAO;
import util.MyPath;
import util.Paging;
import vo.ScreeningVO;

@Controller
public class ScreeningBoardController {
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	ScreeningDAO screening_dao;
	
	//전체 게시물
	@RequestMapping("/screening_board_list.do")
	public String list( Model model, String str_search, String page ) {
		
		int nowPage = 1; 
		
		if( page != null ) {
			nowPage = Integer.parseInt( page );
		}
		
		int start = (nowPage - 1) * MyPath.Screeningboard.BLOCKLIST + 1;
		int end = start + MyPath.Screeningboard.BLOCKLIST - 1;
		
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("start", start);
		map.put("end", end);
		
		List<ScreeningVO> list = screening_dao.selectList(map);
		
		//전체게시글 수 구하기 
		//int rowCount = movie_dao.getRowCount(str_search);
		int rowTotal = screening_dao.getRowTotal();
		
		//페이지 메뉴 생성하기 
				String pageMenu = Paging.getPaging(
									"screening_board_list.do", 
									nowPage, 
									rowTotal, 
									MyPath.Communityboard.BLOCKLIST, 
									MyPath.Communityboard.BLOCKPAGE);
				
			model.addAttribute("list", list);
			model.addAttribute("pageMenu", pageMenu);
				
			return MyPath.Screeningboard.VIEW_PATH + "screening_board_list.jsp";
	}
	
	//상세 내용 보기
	@RequestMapping("/screening_board_view.do")
	public String movieView( Model model, int idx ) {
			ScreeningVO vo = screening_dao.selectOne(idx);
			model.addAttribute("vo", vo);
			return MyPath.Screeningboard.VIEW_PATH + "screening_board_view.jsp";
	}
	
	//검색된 게시물 
	@RequestMapping("/screening_board_list_search.do")
	public String search_list( Model model, String str_search ) {
		int rowCount = screening_dao.getRowCount(str_search);
		
		String search = "all";
		
		if( str_search != null && !str_search.isEmpty() ) {
			search = str_search; 
		}
		
		List<ScreeningVO> list = screening_dao.selectList( search );

		
		model.addAttribute("rowCount", rowCount);
		model.addAttribute("list", list);
		
		return MyPath.Screeningboard.VIEW_PATH + "screening_board_search.jsp";
	}
}
