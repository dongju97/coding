package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.CommentVO;
import vo.CommunityVO;

@Repository("community_dao")
public class CommunityDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	//페이지별 게시글 조회
	public List<CommunityVO> selectList( HashMap<String, Integer> map){
		List<CommunityVO> list = sqlSession.selectList("c.community_board_list", map);
		return list;
	}
	
	//전체 게시물 수 조회 
	public int getRowTotal() {
		int count = sqlSession.selectOne("c.community_board_count");
		return count;
	}
	
	//게시글 추가
	public int insert( CommunityVO vo) {
		int res = sqlSession.insert("c.community_insert", vo);
		return res;
	}
	
	//게시글 조회
	public CommunityVO selectOne( int idx ) {
		CommunityVO vo = sqlSession.selectOne("c.community_view", idx);
		return vo;
	}
	
	//조회수 증가
	public int update_readhit( int idx ) {
		int res = sqlSession.update("c.update_readhit", idx);
		return res;
	} 
	
	//댓글 달기 
	public int comment_insert( CommentVO vo ) {
		int res = sqlSession.insert("c.community_comment", vo);
		return res;
	}
	
	//조회하는 게시글에 해당하는 댓글 조회 
	public List<CommentVO> select_com_One( int idx ){
		List<CommentVO> list = sqlSession.selectList("c.community_comment_count", idx);
		return list;
	}
	
	//조회하는 게시글에 댓글이 몇 개 달렸는지 조회 
	public int getCommentTotal(int idx) {
		int com_count = sqlSession.selectOne("c.community_comment_sum", idx);
		return com_count;
	}
	
	//게시글 삭제
	public int delete( int idx) {
		int res = sqlSession.delete("c.community_board_delete", idx);
		return res;
	}
	
	//게시글 수정 
	public int update(CommunityVO vo) {
		int res = sqlSession.update("c.community_board_update", vo);
		return res;
	}
	
	//검색한 게시글 조회
	/*
	 * public List<CommunityVO> searchList( HashMap<String, Integer> map, String
	 * search_op){ List<CommunityVO> list =
	 * sqlSession.selectList("c.community_search_list", map, search_op); return
	 * list; }
	 */
}
