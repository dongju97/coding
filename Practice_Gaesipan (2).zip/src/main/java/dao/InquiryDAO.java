package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.InquiryVO;

@Repository("inquiry_dao")
public class InquiryDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	//페이지별 게시글 조회
	public List<InquiryVO> selectList( HashMap<String, Integer> map){
		List<InquiryVO> list = sqlSession.selectList("i.inquiry_board_list", map);
		return list;
	}
	
	//전체 게시물 수 조회 
	public int getRowTotal() {
		int count = sqlSession.selectOne("i.inquiry_board_count");
		return count;
	}
	
	//게시글 추가 
	public int insert( InquiryVO vo) {
		int res = sqlSession.insert("i.inquiry_insert", vo);
		return res;
	}
	
	//게시글 조회
	public InquiryVO selectOne( int idx ) {
		InquiryVO vo = sqlSession.selectOne("i.inquiry_view", idx);
		return vo;
	}
	
	//댓글추가를 위한 step값 + 1 
	public int update_step( InquiryVO vo ) {
		int res = sqlSession.update("i.inquiry_board_up_step", vo);
		return res;
	}
	
	//댓글 등록 
	public int reply( InquiryVO vo ) {
		int res = sqlSession.insert("i.inquiry_board_reply", vo);
		return res;
	}
	
	//게시글 삭제 
	public int delete( int idx) {
		int res = sqlSession.delete("i.inquiry_board_delete", idx);
		return res;
	}
}
