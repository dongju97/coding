package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.korea.test.MemberController;

import vo.InquiryVO;
import vo.MemberVO;

@Repository("member_dao")
public class MemberDAO {

	@Autowired
	SqlSession sqlSession;
	
	//회원가입
	public int insert(MemberVO vo) {
		int res = sqlSession.insert("m.member_insert", vo);
		return res;
	}
	
	public MemberVO selectOne(String id) {
		MemberVO vo = sqlSession.selectOne("m.member_one", id);
		return vo;
	}
	
	public MemberVO selectLogin(HashMap<String, Object> map) {
		MemberVO vo = sqlSession.selectOne("m.member_login", map);
		return vo;
	}
	
	public MemberVO select(MemberVO naver_vo) {
		MemberVO vo = sqlSession.selectOne("m.member_outer_login", naver_vo);	
		return vo;
	}
	
	//외부 회원가입
	public int outer_insert(MemberVO naver_vo) {
		int res = sqlSession.insert("m.member_outer_insert", naver_vo);
		return res;
	}
	
	//나의 1대1 문의 
	public List<InquiryVO> memInfo_Inquiry(HashMap<String, Object> map) {
		List<InquiryVO> list = sqlSession.selectList("m.member_myinquiry", map);
		return list;
	}
	
	//나의 1대1 문의 전체 게시물 수 조회 
	public int getRowTotal(String id) {
		int count = sqlSession.selectOne("m.myinquiry_count", id);
		return count;
	}
}
