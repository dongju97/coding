package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.PrefestivalVO;

@Repository("prefestival_dao")
public class PrefestivalDAO {
	
	@Autowired
	SqlSession sqlSession;
	
	
	public List<PrefestivalVO> selectList(){
		List<PrefestivalVO> list = sqlSession.selectList("p.pre_festival_list");
		
		return list;
	}

}
