package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.ScreeningVO;

@Repository("screening_dao")
public class ScreeningDAO {
	
	@Autowired
	SqlSession sqlSession;

	// 전체게시물 조회
	public List<ScreeningVO> selectList( HashMap<String, Integer> map ) {
		List<ScreeningVO> list = sqlSession.selectList("s.screening_board_list", map);
		return list;
	}

	// 게시물 한 건 조회
	public ScreeningVO selectOne(int idx) {
		ScreeningVO vo = sqlSession.selectOne("s.screening_board_one", idx);
		return vo;
	}

	// 검색된 게시물
	public List<ScreeningVO> selectList(String str_search) {
		List<ScreeningVO> list = sqlSession.selectList("s.screening_board_list_search", str_search);
		return list;
	}

	// 전체 게시물 수 조회
	public int getRowTotal() {
		int count = sqlSession.selectOne("s.screening_board_count");
		return count;
	}

	// 검색 게시물 수 조회
	public int getRowCount(String str_search) {
		int count = sqlSession.selectOne("s.screening_board_search_count", str_search);
		return count;
	}
	
}
