package util;

public class MyPath {
	
	//메인페이지용 
	public static class Mainpage{
		public static final String VIEW_PATH = "/WEB-INF/views/mainpage/";
	}
	
	//멤버관리페이지용 
	public static class Memberadminpage{
		public static final String VIEW_PATH = "/WEB-INF/views/memberadminpage/";
		
		//한 페이지에 보여줄 게시물 갯수
		public final static int BLOCKLIST = 5;
		
		//페이지 메뉴 수 
		//<- 1 2 3 -> 
		public final static int BLOCKPAGE = 3;
	}
	
	//상영작게시판용 
	public static class Screeningboard{
		public final static String VIEW_PATH = "WEB-INF/views/screeningboard/";
	
		//한 페이지에 보여줄 게시물 갯수
				public final static int BLOCKLIST = 5;
				
				//페이지 메뉴 수 
				//<- 1 2 3 -> 
				public final static int BLOCKPAGE = 3;
	
	}
	
	//1대1문의게시판용 
	public static class Inquiryboard{
		public final static String VIEW_PATH = "WEB-INF/views/inquiryboard/";
		
		//한 페이지에 보여줄 게시물 갯수
		public final static int BLOCKLIST = 10;
		
		//페이지 메뉴 수 
		//<- 1 2 3 -> 
		public final static int BLOCKPAGE = 3;
	}
	
	//자유게시판용 
	public static class Communityboard{
		public final static String VIEW_PATH = "WEB-INF/views/communityboard/";
		
		//한 페이지에 보여줄 게시물 갯수
		public final static int BLOCKLIST = 10;
		
		//페이지 메뉴 수 
		//<- 1 2 3 -> 
		public final static int BLOCKPAGE = 3;
	}
	
	//기타 페이지들 
	public static class Etcpage{
		public final static String VIEW_PATH = "WEB-INF/views/etc/";
	}
}
