package vo;

public class ScreeningVO {

	private int idx, createYear;
	private String screeningTitle, director, createCountry, running, programNote, directorContent, screeningImage, screeningDate, screeningTime;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getCreateYear() {
		return createYear;
	}
	public void setCreateYear(int createYear) {
		this.createYear = createYear;
	}
	
	public String getScreeningTitle() {
		return screeningTitle;
	}
	public void setScreeningTitle(String screeningTitle) {
		this.screeningTitle = screeningTitle;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getCreateCountry() {
		return createCountry;
	}
	public void setCreateCountry(String createCountry) {
		this.createCountry = createCountry;
	}
	public String getRunning() {
		return running;
	}
	public void setRunning(String running) {
		this.running = running;
	}
	public String getProgramNote() {
		return programNote;
	}
	public void setProgramNote(String programNote) {
		this.programNote = programNote;
	}
	public String getDirectorContent() {
		return directorContent;
	}
	public void setDirectorContent(String directorContent) {
		this.directorContent = directorContent;
	}
	public String getScreeningImage() {
		return screeningImage;
	}
	public void setScreeningImage(String screeningImage) {
		this.screeningImage = screeningImage;
	}
	public String getScreeningDate() {
		return screeningDate;
	}
	public void setScreeningDate(String screeningDate) {
		this.screeningDate = screeningDate;
	}
	public String getScreeningTime() {
		return screeningTime;
	}
	public void setScreeningTime(String screeningTime) {
		this.screeningTime = screeningTime;
	}

}
